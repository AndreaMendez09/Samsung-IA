﻿# Coding Practice #0619
#----------------------------------------------------------------------------------

import numpy as np
import cv2

# Ve al directorio donde se encuentran las imágenes. 
# os.chdir(r'~~')                     				  # Ajusta el path.

# Carga una imagen en blanco y negro. 
img = cv2.imread('picture_LenaSoderberg.jpg',0)         

# 1. Thresholding.

# 1.1. Thresholding binario (threshold = 80) y muéstralo.


# 1.2. Thresholding adaptativo y muéstralo.

