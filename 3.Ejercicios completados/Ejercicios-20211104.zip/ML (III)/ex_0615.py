﻿# Coding Practice #0615
#----------------------------------------------------------------------------------
import numpy as np
import cv2

# Ve al directorio donde se encuentran las imágenes. 
# os.chdir(r'~~')                     				  # Ajusta el path.

# 1. Trabajando con datos en formato imagen.

# 1.1. Abre una imagen en color y muéstrala.


# 1.2. Conviértela a escala de grises y muéstrala.


# 1.3. Conviértela a HSV y separa los canales: Hue, Saturation, Value. Muestra por pantalla cada canal.


