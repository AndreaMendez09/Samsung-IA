﻿# Coding Practice #0617
#----------------------------------------------------------------------------------

import numpy as np
import cv2

# Ve al directorio donde se encuentran las imágenes. 
# os.chdir(r'~~')                     				  # Ajusta el path.

# 1. Filtros morfológicos.
# 1.1. Abre una imagen en blanco y negro y muéstrala.

# 1.1. Erosión y dilatación:
# Erosion: Sustituye píxeles blancos por negros.

# Dilation: Sustituye píxeles negros por blancos.


