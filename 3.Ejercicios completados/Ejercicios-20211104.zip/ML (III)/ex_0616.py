﻿# Coding Practice #0616
#----------------------------------------------------------------------------------

import numpy as np
import cv2

# Ve al directorio donde se encuentran las imágenes. 
# os.chdir(r'~~')                     				  # Ajusta el path.


# 1. Filtros convolucionales.
# 1.1. Abre una imagen en blanco y negro y muéstrala.


# 1.1. Aplica un kernel de desenfoque gaussiano y muéstralo.


# 1.2. Aplica un kernel de Sharpening y muéstralo.


# 1.3. Aplica el kernel de Outline #1 y muéstralo.


# 1.4. Aplica el kernel de Outline #2 y muéstralo.


