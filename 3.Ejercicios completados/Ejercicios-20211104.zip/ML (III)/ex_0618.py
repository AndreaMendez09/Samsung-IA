﻿# Coding Practice #0618
#----------------------------------------------------------------------------------

import numpy as np
import cv2

# Ve al directorio donde se encuentran las imágenes. 
# os.chdir(r'~~')                     				  # Ajusta el path.

# Abre y muestra una imagen en color


# 1. Transformación de los datos en formato imagen.
# 1.1. Redimensiona la imagen y muéstralo.


# 1.2. Rota la imagen con una transformación afín y muéstralo.

